# React Firebase Authentication Example

Put your credentials to `.env`.

Run `yarn start` to start application.